<?php
$page_title = 'New Password Form';
$PAGE='new_pass';
$page_css = 'includes/forms.css';
require 'includes/header.php';


if (isset($_POST['submitted'])) {
	require 'ecomplay_connect.php';

	
	// Check for an email address:
	if (empty($_POST['email'])) {
		$errors[] = 'You forgot to enter your email address.';
	} else {
		$e = escape_data($_POST['email'], $dbc);
	}

	// Check for the current password:
	if (empty($_POST['password'])) {
		$errors[] = 'You forgot to enter your current password.';
	} else {
		$p =  escape_data($_POST['password'], $dbc);
	}

	// Check for a new password and match 
	// against the confirmed password:
	if (!empty($_POST['password1'])) {
		if ($_POST['password1'] != $_POST['password2']) {
			$errors[] = 'Your new password did not match the confirmed password.';
		} else {
			$np =  escape_data($_POST['password1'], $dbc);
		}
	} else {
		$errors[] = 'You forgot to enter your new password.';
	}
	
	if (empty($errors)) { // If everything's OK:
        // Check if user entered a correct  email address/password combination:
		$q = "SELECT cust_id FROM customers WHERE (email='$e' AND password=SHA1('$p') )";
		if (isset($_POST['confirm'])){
					$confirm = $_POST['confirm'];
					if ($confirm == 'yes'){
						$to = $email; 
						$body = 'You changed your password for The Pit!';
						$body .= "\nThank you for using The Pit for all your band merch needs.";
						mail ($to, 'The Pit - Password Change Notification', $body);
				}
		}
		$r = @mysqli_query($dbc, $q);
		$num = @mysqli_num_rows($r);
		if ($num == 1) { // A match was made.
			// Get the user_id:
			$row = mysqli_fetch_array($r, MYSQLI_NUM);
  
			// Make the UPDATE query:  
			$q = "UPDATE customers SET password=SHA1('$np') WHERE cust_id=$row[0]";		
			
			if (mysqli_affected_rows($dbc) == 1) { // If it ran OK.

				// Print a message.
				echo '<h2>Thank you!</h2>
				<p>Your password has been updated. In Chapter 12 you will actually be
				able to log in!</p>'; 	

			} else { // If it did not run OK.

				// Public message:
				echo '<h2 class="error">System Error</h2>
				<p class="error">Your password could not be changed due to a system
				error. We apologize for any inconvenience.</p>';  
    
				// Debugging message:
				echo '<p>' . mysqli_error($dbc) . '<br><br>Query: ' . $q . '</p>';
			}  // END if (mysqli_affected_rows($dbc) == 1)  IF
			
			mysqli_close($dbc); // Close the database connection.
     
			// Include the footer and quit the script (to not show the form).
			include 'includes/footer.php'; 
			exit();
			} else { // Invalid email address/password combination.
				echo '<h2 class="error">Error!</h2>
				<p class="error">The email address and password do not match those on file.</p>';
		}  // END  if ($num == 1)  IF
			
	} else { // Report the errors.

		echo '<h2>Error!</h2>
		<p class="error">The following error(s) occurred:<br>';
		foreach ($errors as $msg) { // Print each error.
			echo " - $msg<br />\n";
		}
		echo '</p><p>Please try again.</p>';
	
	} // End of if (empty($errors)) IF.

	mysqli_close($dbc); // Close the database connection.
		
} // End of the main Submit (if) conditional on isset($_POST['submitted'])


?>
    <h1>New Password</h1>
	
  <main>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
	
	<div class="field">
        <label for="email">Email*:</label>
        <input type="email" name="email"  id="email" required   autofocus
		value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>">
        </div>
		 
	<div class="field">
        <label for="password">Current Password*:</label>
        <input type="password" id="password" name="password" required
		value="<?php if (isset($_POST['password'])) echo $_POST['password']; ?>">
        </div>

	<div class="field">
	   <label for="password1">New Password*:</label>
	   <input type="password" id="password1" name="password1" maxlength="19" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}"
	   title="Must contain: lowercase character, uppercase character, a number, and be at least 7 characters" 
	   value="<?php if (isset($_POST['password1'])) echo $_POST['password1']; ?>" required>
	</div>
	<div class="field">
	      <label for="password2">Re-enter Password*:</label>
	      <input type="password" id="password2" name="password2" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}"
		  title="Must contain: lowercase character, uppercase character, a number, and be at least 7 characters"
		  value="<?php if (isset($_POST['password2'])) echo $_POST['password2']; ?>" required>
	</div>
	
	<div class="field">
		<label> Confirmation Email?</label>
		<input type="radio" id="yes" name = "confirm" value = "yes">
			<label for="yes" class="radios">Yes</label>
		<input type="radio" id="no" name = "confirm" value = "no" checked>
			<label for="no" class = "radios">No</label>
	</div>

    <input type="hidden" name="submitted" value="TRUE">
      <div class="field">
	<button type="submit" class="formButton">Submit My Information</button>
      </div>


</form>
</main>


<div class="container">
			<aside class="sidebar">
				<h2>Relax A Little!</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/7vfjdnQr5I6WjzcxtP5dEt"></iframe>
			</aside>
			</div>

<?php
require 'includes/footer.php';
?>

</body>
</html>
