<?php
$page_title = 'New Customer Form';
$PAGE='cust_form';
require_once 'includes/config.inc.php';
$page_css = 'includes/forms.css';
require 'includes/functions.php';
require 'includes/header.php';
if (!isset($_SESSION['cust_id'])) {
        require_once 'recaptchalib.php';
        include 'recaptcha.inc.php';
    }

if (isset( $_POST['submitted'])){
	
	require(db);
	
	$errors = array(); 
    // validate the first name:
   if (!empty($_POST['firstname'])) {
        $firstname = escape_data($_POST['firstname'], $dbc);
	} else {
        $errors['firstname'] = 'Please provide your first name.';
	}
	// validate the last name:
   if (!empty($_POST['lastname'])) {
        $lastname = escape_data($_POST['lastname'], $dbc);
	} else {
        $errors['lastname'] = 'Please provide your last name.';
	}	
  // validate the email:
   if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $email = escape_data($_POST['email'], $dbc);
	} else {
		$errors['email'] = 'Please provide your email in the format: "name@domain.com".';
	} 
	// validate the phone number:
   if (!empty($_POST['phone'])) {
        $phone = escape_data($_POST['phone'], $dbc);
	} else {
        $errors['phone'] = 'Please provide your phone number in the format: "(555) 555-5555".';
	} 
	// validate the address:
   if (!empty($_POST['address'])) {
        $address = escape_data($_POST['address'], $dbc);
	} else {
        $errors['address'] = 'Please provide your address.';
	} 
	// validate the city:
   if (!empty($_POST['city'])) {
        $city = escape_data($_POST['city'], $dbc);
	} else {
        $errors['city'] = 'Please provide your city.';
	} 
	//validate the state
	if (empty($_POST['state'])) {
        $errors['state'] = 'Please choose your state.';
	} else {
        $state = escape_data($_POST['state'], $dbc);
	}
	// validate the zipcode:
   if (!empty($_POST['zip'])) {
        $zip = escape_data($_POST['zip'], $dbc);
	} else {
        $errors['zip'] = 'Please provide your zip code.';
	} 
  // validate the password    
    if ( !empty($_POST['password']) && !empty($_POST['password2']) ) {
		$pass = $_POST['password'];
		$pass2 = $_POST['password2'];
	if ( $pass > 7 AND $pass2 > 7 AND $pass == $pass2 ) {
			$pass = escape_data($_POST['password'], $dbc);
			$pass2 = escape_data($_POST['password2'], $dbc);
		} 
    } else {
        $errors['pass'] = 'Your passwords did not match. Please make sure that they are not blank 
		and that they include AT LEAST one lowercase character, uppercase character, number, and are 8 characters long.';
    }
  // validate the comments:
   if (!empty($_POST['comments'])) {
	  $comments = escape_data($_POST['comments'], $dbc);
	} else {
        $errors['comments'] = 'Please provide some comments.';
	}
	
	/*if(isset($_POST['g-recaptcha-response'])){
          $captcha=$_POST['g-recaptcha-response'];
        }
        if(!$captcha){
          $errors[] =  '<h2 class="error">Please check the captcha form.</h2>';
          exit;
        }
        $response=file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$CaptchaLoginPrivateKey."&response=".$captcha."&remoteip=".$_SERVER['REMOTE_ADDR']);
		$data = json_decode($response);  */
	
	
	if (empty($errors)) { // If everything's OK.
	//if (isset($data->success) AND $data->success==true) {
		
		// Make sure the email address is available:
		$q = "SELECT cust_id FROM customers WHERE email='$email'";
		$r = mysqli_query ($dbc, $q) or trigger_error("Query: $q\n<br>MySQL Error: " . mysqli_error($dbc));

		if (mysqli_num_rows($r) == 0) { // Available.

			// Create the activation code:
			$a = md5(uniqid(rand(), true));
			
			//Add user to db
			$q = "INSERT INTO customers (first_name, last_name, email, pass, city, state, zip, street, phone, date_created) 
			VALUES('$firstname', '$lastname', '$email', SHA1('$pass'), '$city', '$state', '$zip', '$address', $phone, NOW())";
			$r = mysqli_query ($dbc, $q) or trigger_error("Query: $q\n<br />MySQL Error: " . mysqli_error($dbc));

			if (mysqli_affected_rows($dbc) == 1) { // If it ran OK.

				/* Send the email:
				$body = "Thank you for registering at The Pit! To activate your
				account, please click on the link below:\n\n";
				$body .= BASE_URL . 'activate.php?x=' . urlencode($email);
				mail($_POST['email'], 'The Pit Registration Confirmation', $body, 'From: root@math.mercyhurst.edu'); */
				redirect_user('customer_login.php');
				
				if (isset($_POST['confirm'])){
					$confirm = $_POST['confirm'];
					if ($confirm == 'yes'){
						$to = 'eletic40@lakers.mercyhurst.edu'; 
						$body = $_POST['comments'];
						$body .= "\nFrom:\n$firstname $lastname\n$email";
						mail ($to, 'The Pit Has A New User!', $body);
					}
				}

				/* Finish the page:
				echo '<h3 class="success">Thank you for registering! A confirmation email has been sent
				to your address. Please click on the link in that email in order to
				activate your account.</h3>';
				include 'includes/footer.php'; // Include the HTML footer.
				exit(); // Stop the page. */

			} else { // If it did not run OK.
				echo '<p class="error">You could not be registered due to a system
				error. We apologize for any inconvenience.</p>';
			}

		} else { // The email address is not available.
			echo '<p class="error">That email address has already been registered. If you have forgotten your password, use the link at right to have your password sent to you.</p>';
		}

	} else { // If one of the data tests failed.
		echo '<p class="error">Please try again.</p>';
	}

	mysqli_close($dbc);	
 //} // END else on the  g-recaptcha-response
} 
?>
    <h1>New Customer</h1>
	
  <main>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
      <p class="validation-tip">
	* Indicates a required field.
      </p>
	  
      <fieldset>
        <legend>Enter your information in the form:</legend>

	<div class="field">
           <label for="firstname">First Name*: </label>
	   <input type="text" name="firstname"  id="firstname" placeholder="e.g. Jane"
		  maxlength="20" value="<?php if (isset($_POST['firstname'])) echo $_POST['firstname']; ?>" autofocus required>
		  <p class="error"><?php if (isset($errors['firstname'])) { echo $errors['firstname']; } ?></p>
	</div>
	
	<div class="field">
           <label for="lastname">Last Name*: </label>
	   <input type="text" name="lastname"  id="lastname" placeholder="e.g. Doe"
		  maxlength="40" value="<?php if (isset($_POST['lastname'])) echo $_POST['lastname']; ?>" autofocus required>
		  <p class="error"><?php if (isset($errors['lastname'])) { echo $errors['lastname']; } ?></p>
	</div>

	<div class="field">
	   <label for="email">Email*:</label>
	   <input type="email" name="email"  id="email"
		  placeholder="e.g. jdoe@lakers.mercyhurst.edu" value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>" required>
		  <p class="error"><?php if (isset($errors['email'])) { echo $errors['email']; } ?></p>
        </div>
		
	<div class="field">
		<label> Confirmation Email?</label>
		<input type="radio" id="yes" name = "confirm" value = "yes">
			<label for="yes" class="radios">Yes</label>
		<input type="radio" id="no" name = "confirm" value = "no" checked>
			<label for="no" class = "radios">No</label>
	</div>
		
	<div class="field">
	<label for="phone">Phone Number*:</label>
	<input type="tel" id="phone" name="phone" maxlength="12" placeholder="e.g. 555-555-5555" 
	pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" title="Please format the number as such: 555-555-5555" 
	value="<?php if (isset($_POST['phone'])) echo $_POST['phone']; ?>" required>
	<p class="error"><?php if (isset($errors['phone'])) { echo $errors['phone']; } ?></p>
	</div>

	<div class="field">
	   <label for="password">Password*:</label>
	   <input type="password" id="password" name="password" maxlength="19" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}"
	   title="Must contain: lowercase character, uppercase character, a number, and be at least 8 characters" 
	   value="<?php if (isset($_POST['password'])) echo $_POST['password']; ?>" required>
	   <p class="error"><?php if (isset($errors['pass'])) { echo $errors['pass']; } ?></p>
	</div>
	<div class="field">
	      <label for="password2">Re-enter Password*:</label>
	      <input type="password" id="password2" name="password2" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}"
		  title="Must contain: lowercase character, uppercase character, a number, and be at least 8 characters"
		  value="<?php if (isset($_POST['password2'])) echo $_POST['password2']; ?>" required>
		  <p class="error"><?php if (isset($errors['pass'])) { echo $errors['pass']; } ?></p>
	</div>
	
	<div class="field">
		<label for="address">Street Address*:</label>
		<input type="text" id="address" name="address" maxlength="100" placeholder="e.g. 123 Main Street"
		value="<?php if (isset($_POST['address'])) echo $_POST['address']; ?>" required>
		<p class="error"><?php if (isset($errors['address'])) { echo $errors['address']; } ?></p>
	</div>
	
	<div class="field">
	<label for="city">City*:</label>
	<input type="text" id="city" name="city" maxlength="100" placeholder="e.g. Pittsburgh"
	value="<?php if (isset($_POST['city'])) echo $_POST['city']; ?>" required>
	<p class="error"><?php if (isset($errors['city'])) { echo $errors['city']; } ?></p>
	</div>
	
	<?php // an array containing all 50 states plus DC
	    $state_array = array('AL'=>'Alabama','AK'=>'Alaska','AZ'=>'Arizona','AR'=>'Arkansas','CA'=>'California',
	  'CO'=>'Colorado','CT'=>'Connecticut','DE'=>'Delaware','DC'=>'D.C.','FL'=>'Florida','GA'=>'Georgia',
	  'HI'=>'Hawaii','ID'=>'Idaho','IL'=>'Illinois','IN'=>'Indiana','IA'=>'Iowa','KS'=>'Kansas','KY'=>'Kentucky',
	  'LA'=>'Louisiana','ME'=>'Maine','MD'=>'Maryland','MA'=>'Massachusetts','MI'=>'Michigan','MN'=>'Minnesota',
	  'MS'=>'Mississippi','MO'=>'Missouri','MT'=>'Montana','NE'=>'Nebraska','NV'=>'Nevada','NH'=>'New Hampshire',
	  'NJ'=>'New Jersey','NM'=>'New Mexico','NY'=>'New York','NC'=>'North Carolina','ND'=>'North Dakota',
	  'OH'=>'Ohio','OK'=>'Oklahoma','OR'=>'Oregon','PA'=>'Pennsylvania','RI'=>'Rhode Island',
	  'SC'=>'South Carolina','SD'=>'South Dakota','TN'=>'Tennessee','TX'=>'Texas','UT'=>'Utah','VT'=>'Vermont',
	  'VA'=>'Virginia','WA'=>'Washington','WV'=>'West Virginia','WI'=>'Wisconsin','WY'=>'Wyoming');

	  ?>
	
	<div class="field">
	<label for="state">State*:</label>
	<select name="state" id="State">
        <option value="">Please choose</option>
		<?php //now output the states array
		// output the array in a foreach loop
			foreach ($state_array as $id => $name){
				echo "<option value=\"$id\""; // \ is used to escape double quotes so the echo statement doesn't end early
				if (isset($_POST['state'])) {
					if ($_POST['state'] == $state) {
						echo ' selected';
					}
				};
				echo ">$name</option>\n";
			}
		?>
	</select>
	<p class="error"><?php if (isset($errors['state'])) { echo $errors['state']; } ?></p>
	</div>
	
	<div class="field">
		<label for="zip">ZIP Code*:</label>
		<input type="text" id="zip" name="zip" 
		value="<?php if (isset($_POST['zip'])) echo $_POST['zip']; ?>" required>
		<p class="error"><?php if (isset($errors['zip'])) { echo $errors['zip']; } ?></p>
	</div>

	<div class="field">
           <label for="comments">Comments*:</label>
	     <textarea name="comments" id="comments" rows="4" cols="50"
		 value="<?php if (isset($_POST['comments'])) echo $_POST['comments']; ?>"></textarea>
		 <p class="error"><?php if (isset($errors['comments'])) { echo $errors['comments']; } ?></p>
        </div>
		
	<?php //if (isset($CaptchaLoginPublicKey)) { // works on math.mercyhurst.edu
	  //echo '<div class="g-recaptcha" data-sitekey="' .$CaptchaLoginPublicKey .'"></div>';
	  //}
	  ?>
	  
      </fieldset>

    <input type="hidden" name="submitted" value="TRUE">
      <div class="field">
	<button type="submit" class="formButton">Submit My Information</button>
      </div>


</form>
</main>


<div class="container">
			<aside class="sidebar">
				<h2>Relax A Little!</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/7vfjdnQr5I6WjzcxtP5dEt"></iframe>
			</aside>
			</div>

<?php
require 'includes/footer.php';
?>

</body>
</html>
