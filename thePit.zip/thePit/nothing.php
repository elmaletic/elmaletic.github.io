<?php       
    $page_title = 'Nothing More';
    $PAGE='NothingMore';
    require 'includes/header.php';
?>
	  
	  
          <h1 id ="top">"Hold your head up, follow your heart."</h1>

          <main>
			
			<section class="content">
			  <br>
			  <h2><a href="nothing">Nothing More</a></h2>
			  <br>
			  <img src="http://via.placeholder.com/200x200">
			  <br>
			  <p> Nothing More has been around for a while, but they recently got nominated for a Grammy which should signal how 
				good this band is, even if they didn't win the Grammy. Fans seem to disagree on if they're consider progressive rock
				or progressive metal, but either way Nothing More definitely proves the point that rock and roll is not dead. 
				Whether they're proggy metal or proggy rock, we'll let you decide. :)
			  </p>
			</section>
          </main>
		  
		  
		   <div class="container">
			<aside class="sidebar">
				<h2>What We're Jamming To:</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/0tnnf548YZPUCqhzKZfH4a"></iframe>
			</aside>
			</div>
		  
		
  
    <footer>
	<?php
	include 'includes/footer.php';
	?>
    </footer>
    </div> 

  </body>
</html>