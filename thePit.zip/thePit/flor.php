<?php       
    $page_title = 'Flor';
    $PAGE='Flor';
    require 'includes/header.php';
?>
	  
          <h1 id ="top">"Wait for me and I'll be back again."</h1>

          <main>
			
			<section class="content">
			  <br>
			  <h2><a href="flor">Flor</a></h2>
			  <br>
			  <img src="http://via.placeholder.com/200x200">
			  <br>
			  <p> The Spanish word for "flower," Flor -- much like Envy on the Coast -- offers a variety of chill beats and 
				relaxing music. It might be hard to get into at first, but trust us, after your third or fourth listen,
				you'll be getting their songs stuck in your head for days to come!
			  </p>
			</section>
          </main>
		  
		  
		   <div class="container">
			<aside class="sidebar">
				<h2>What We're Jamming To:</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/0tnnf548YZPUCqhzKZfH4a"></iframe>
			</aside>
			</div>
		  
		
  
    <footer>
	<?php
	include 'includes/footer.php';
	?>
    </footer>
    </div> 

  </body>
</html>