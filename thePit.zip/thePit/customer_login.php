<?php
$page_title = 'Customer Login';
$PAGE='login';
$page_css = 'includes/forms.css';
require_once 'includes/config.inc.php';
require 'includes/functions.php';
require 'includes/header.php';


// Initialize a session:
    session_name ('thePit');
    session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	require (db);
		$errors = array(); 
	// validate the email:
   if (!empty($_POST['email'])) {
        $email = escape_data($_POST['email'], $dbc);
	} else {
        echo '<p class="error">You forgot to enter your email!</p>';
	}
	// validate the password:
    if (!empty($_POST['password'])) {
         $pass = escape_data($_POST['password'], $dbc);
	} else {
         echo '<p class="error">You forgot to enter your password!</p>';
	}
	
	if ($email && $pass) { // If everything's OK.

		// Query the database:
		$q = "SELECT cust_id, first_name FROM customers WHERE (email='$email' AND pass=SHA1('$pass'))";
		$r = mysqli_query ($dbc, $q) or trigger_error("Query: $q\n<br />MySQL Error: " . mysqli_error($dbc));

		if (@mysqli_num_rows($r) == 1) { // A match was made.

			// Register the values:
		        $_SESSION = mysqli_fetch_array ($r, MYSQLI_ASSOC);
			// Store the HTTP_USER_AGENT:
			$_SESSION['agent'] = sha1($_SERVER['HTTP_USER_AGENT']);
			$id = $_SESSION['cust_id'];

			mysqli_free_result($r);
			mysqli_close($dbc);

			// Redirect the user:
			redirect_user('products.php');

		} else { // No match was made.
			echo '<p class="error">Either the email address and password entered do not match
			those on file or you have not yet activated your account.
			<br>
			If you are a new customer and need to create an account, click <a href = "new_customer.php">here</a>.
			</p>';
		}

	} else { // If everything wasn't OK.
		echo '<p class="error">Please try again.</p>';
	}

	mysqli_close($dbc);
} // End of if on . . .
?>
    <h1>Login:</h1>
	
	
  <main>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
   	<div class="field">
	   <label for="email">Email*:</label>
	   <input type="email" name="email"  id="email"
		  placeholder="e.g. jdoe@lakers.mercyhurst.edu" value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>" required>
        </div>
		
	<div class="field">
	   <label for="password">Password*:</label>
	   <input type="password" id="password" name="password" maxlength="19" required>
	</div>

    <input type="hidden" name="submitted" value="TRUE">
      <div class="field">
	<button type="submit" class="formButton">Log In</button>
      </div>


</form>
</main>


<div class="container">
			<aside class="sidebar">
				<h2>Relax A Little!</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/7vfjdnQr5I6WjzcxtP5dEt"></iframe>
			</aside>
</div>

<?php
require 'includes/footer.php';
?>

</body>
</html>
