<?php 
       $page_title = 'Admin -  Edit a User';
       $short_title = 'Edit a User';
       $PAGE='edituser';
	   $page_css = 'includes/adminforms.css';
       require 'includes/adminhead.php';
      echo '<h2>Admin - Edit a User</h2>';

// Check for a valid user ID, through GET or POST:
if ( (isset($_GET['id'])) && (is_numeric($_GET['id'])) ) { // From customers.php
	$id = $_GET['id'];
} elseif ( (isset($_POST['id'])) && (is_numeric($_POST['id'])) ) { // Form submission.
	$id = $_POST['id'];
} else { // No valid ID, kill the script.
	echo '<p class="error">This page has been accessed in error.</p>';
	require '../includes/footer.php';
	exit();
}

        require 'ecomplay_connect.php';


// Check if the form has been submitted:
if (isset($_POST['submitted'])) {

	$errors = array();

	// Check for a first name:
	if (empty($_POST['first_name'])) {
		$errors[] = 'You forgot to enter the first name.';
	} else {
		$fn = escape_data($_POST['first_name'], $dbc);
	}

	// Check for a last name:
	if (empty($_POST['last_name'])) {
		$errors[] = 'You forgot to enter the last name.';
	} else {
		$ln = escape_data($_POST['last_name'], $dbc);
	}

	// Check for an email address:
	if (empty($_POST['email'])) {
		$errors[] = 'You forgot to enter the email address.';
	} else {
		$e = escape_data($_POST['email'], $dbc);
	}

	if (empty($errors)) { // If everything's OK.
		$q = "SELECT cust_id FROM customers WHERE email = '$e' AND cust_id != $id";
		$r = @mysqli_query($dbc,$q);
		if (mysqli_num_rows($r) == 0) {
			// Make the query:
              $q = "UPDATE customers SET first_name='$fn', last_name='$ln', email='$e'
                    WHERE cust_id=$id LIMIT 1";
              $r = @mysqli_query ($dbc, $q);
			  if (mysqli_affected_rows($dbc) == 1) { // If it ran OK.

					// Print a message:
                    echo '<p>The user has been edited.</p>';

              } else { // If it did not run OK.
                    // Public message.
                    echo '<p class="error">Either no changes were made OR the
                    user could not be edited due to a system error.
                    We apologize for any inconvenience.</p>';
                    // Debugging message.
                    echo '<code>' . mysqli_error($dbc) . '<br>
					Query: ' . $q . '</code><br>';
              }



        } else { // Already registered.
           echo '<p class="error">The email address has already been registered.</p>';
        }  // END if (mysqli_num_rows($r) == 0)   IF

	} else { // Report the errors.

		echo '<p class="error">The following error(s) occurred:<br>';
		foreach ($errors as $msg) { // Print each error.
			echo " - $msg<br>\n";
		}
		echo '</p><p>Please try again.</p>';

	} // End of if (empty($errors)) IF.

} // End of submit conditional.

   // Retrieve the user's information:
   $q = "SELECT first_name, last_name, email FROM customers WHERE cust_id=$id";
   $r = @mysqli_query($dbc, $q);

   if (mysqli_num_rows($r) == 1) { // Valid user ID, show the form.
	$row = mysqli_fetch_array($r,MYSQLI_NUM);
	// print '<pre>'.print_r($row,1).'</pre>'; //prints out the array and each row. v helpful
?>


<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
    <fieldset>
         <legend>Edit the User Information</legend>

         <div class="field">
           <label for="fname">First Name:</label>
           <input type="text" name="first_name"  id="fname" maxlength="45" value="<?php echo $row[0]?>">
           </div>
         <div class="field">
           <label for="lname">Last Name:</label>
           <input type="text" name="last_name"  id="lname" maxlength="45" value="<?php echo $row[1]?>">
         </div>
         <div class="field">
           <label for="email">Email:</label>
           <input type="email" name="email"  id="email" maxlength="100" value="<?php echo $row[2]?>">
         </div>
         <input type="hidden" name="id" value="<?php echo $id; ?>">
    </fieldset>
    <div class="field">
          <button type="submit" class="formButton">Edit User</button>
    </div>
	<input type="hidden" name="submitted" value="TRUE">
</form>


<?php

} else { // Not a valid user ID.
	echo '<p class="error">This page has been accessed in error.</p>';
}

mysqli_close($dbc);
?>

	<div class="container">
		<aside class="sidebar">
			<h2>Relax A Little!</h2>
			<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/7vfjdnQr5I6WjzcxtP5dEt"></iframe>
		</aside>
	</div>
<?php
require '../includes/footer.php';
?>
</body>
</html>