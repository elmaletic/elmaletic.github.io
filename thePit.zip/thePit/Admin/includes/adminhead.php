<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	 <title> <?php
			echo $page_title;
		?></title>
	<meta name="description" content="Learning PHP, Mercyhurst University">
    <meta name="author" content="Elma Letic">
	<link rel="stylesheet" href="includes/pit.css">
	
	<?php
	if (isset($page_css)){
      echo '   <link type="text/css" rel="stylesheet" href="'.$page_css.'">';
   }
   ?>

</head>
<body>

	<header class="masthead">	  
		<img src="images/pit_admin.png" alt="Gritty spotlight that says 'The Pit' and 'Where Rebellion Thrives'">
		
		<div id="wrapper">     
			<?php  include('adminnav.php'); ?> 
      
	</header><!-- end masthead -->
    
	<div class="container">