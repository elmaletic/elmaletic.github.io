    <?php if (!isset($PAGE) ) {$PAGE='home';} ?> 
      <nav class="<?php echo $PAGE; ?>">
    <div class="navbar">
		<nav>
			<a href="index.php">Home</a>
				<a href="admin_users.php">Customers</a>
			<div class="dropdown">
				<button class="dropbtn">Products
					<i class="fa-fa-caret-down"></i>
				</button>
				<div class="dropdown-content">
				<a href="admin_products.php">View All Products</a>
				<a href="add_product.php">Add Product</a>
			</div>
			</div> 
			<div class="dropdown">
				<button class="dropbtn">Profile
					<i class="fa-fa-caret-down"></i>
				</button>
			<div class="dropdown-content">
			<a href="login.php">Log In</a>
			<a href="logout.php">Log Out</a>
			<a href="new_password.php">New Password</a>
			<a href="edit_admin_profile.php">Edit Admin Profile</a>
			</div>
			</div>
	</div>
		</nav> 