<?php
    $page_title = 'Admin - Products';
    $short_title='Products';
    $PAGE='adminproducts';
	$page_css='includes/admintables.css';
    require 'includes/adminhead.php';

// Page header:
echo '<h2>List of Products</h2>';

require 'ecomplay_connect.php'; //connect to the db 


//the number of records to display on a page
		$display = 20;
		
		// Determine how many pages there are...
		if (isset($_GET['p']) && is_numeric($_GET['p'])) { // Already been determined.
			$pages = $_GET['p'];
		} else { // Need to determine.
			// Count the number of records:
			$q = "SELECT COUNT(product_id) FROM products";
			$r = @mysqli_query ($dbc, $q);
			$row = @mysqli_fetch_array ($r, MYSQLI_NUM);
			$records = $row[0];

			// Calculate the number of pages...
			if ($records > $display) {    // More than 1 page.
				$pages = ceil ($records/$display); //ceiling - next integer up (rounded) whereas floor is next integer down.
			} else {
				$pages = 1;
			}
		} // END   (isset($_GET['p'])   IF.
		
		// Determine where in the database to start returning results...
		if (isset($_GET['s']) && is_numeric($_GET['s'])) {
			$start = $_GET['s'];
		} else {
			$start = 0;
		}
		
		// Determine the sort...   
		// Default is by product name.
		$sort = (isset($_GET['sort'])) ? $_GET['sort'] : 'pn';

		// Determine the sorting order:
		switch ($sort) {
			default:
					$order_by = 'product_name ASC';
					$sort = 'pn';
					break;
			case 'cn':
					$order_by = 'category_name ASC';
					break;
			case 'up':
					$order_by = 'unit_price ASC';
					break;
		}


//make the query
$q = "SELECT p.product_name, p.unit_price, p.product_id, c.category_name 
	 FROM products AS p, categories AS c 
	 WHERE p.category_id = c.category_id 
	 ORDER BY $order_by LIMIT $start, $display ";
	 
$r = @mysqli_query($dbc,$q);

$num = mysqli_num_rows($r);

if ($num > 0) { // If it ran OK, display the records.

// Table header:
        echo '<table class="products">
         <colgroup>
           <col id="edit"><col id="delete"><col id="product"><col id = "category"><col id="price">
        </colgroup>
        <thead>
             <tr>
				<th>Edit</th>
				<th>Delete</th>
                 <th><a href="admin_products.php?sort=pn">Product</a></th>
                 <th><a href="admin_products.php?sort=cn">Category</a></th>
                 <th><a href="admin_products.php?sort=up">Price</a></th>
              </tr>
        </thead>
        <tbody>
';
    // Fetch and print all the records:
      while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
		echo '<tr>
				<td><a href ="edit_product.php?id=' . $row['product_id'] . '">Edit</a></td>
				<td><a href ="delete_product.php?id=' . $row['product_id'] . '">Delete</a></td>
				<td>' . $row['product_name'] . '</td>
				<td>' . $row['category_name'] . '</td>
				<td>' . $row['unit_price'] . '</td>
			  </tr>';

      }  // END the  while ($row = mysqli_fetch_array()  loop    
		
	echo "\n</tbody>\n
     </table>\n";
	 
	
	mysqli_free_result($r);

 } else { // If no records were returned.
   echo '<p class="error">There are currently no registered products.</p>';
 } // END if ($num > 0)  IF

mysqli_close($dbc);

// Make the links to other pages, if necessary.
       if ($pages > 1) {

           // Add some spacing and start a paragraph:
           echo '<br><p class="out">';

           // Determine what page the script is on:
           $current_page = ($start/$display) + 1;

           // If it's not the first page, make a Previous link:
  if ($current_page != 1) {
                echo '<a href="admin_products.php?s=' . ($start - $display) .
		     '&amp;p=' . $pages . '&amp;sort=' . $sort . '">Previous</a> &nbsp;';
	    }
	    
	    // Make all the numbered pages:
	    for ($i = 1; $i <= $pages; $i++) {
                if ($i != $current_page) {
		    echo '&nbsp; <a href="admin_products.php?s=' . (($display * ($i - 1))) .
			  '&amp;p=' . $pages . '&amp;sort=' . $sort . '">' . $i . '</a> &nbsp;';
                } else {
                        echo '&nbsp;   ' . $i . ' ';
                }
		
	    } // End of FOR loop.
        
	    // If it's not the last page, make a Next button:
	    if ($current_page != $pages) {
		echo '&nbsp; <a href="admin_products.php?s=' . ($start + $display) .
		   '&amp;p=' . $pages . '&amp;sort=' . $sort . '">Next</a>';
	    }
	
	  echo '</p>'; // Close the paragraph
        } // End of if($pages)  links section.

//NO SIDEBAR SO THE TABLE CAN USE THE ENTIRE WIDTH OF THE CONTENT
//SIDEBAR GETS PUSHED TO THE BOTTOM, AND IT ALSO LOOKS BETTER W/O A SIDEBAR

include '../includes/footer.php';
?>

</body>
</html?
