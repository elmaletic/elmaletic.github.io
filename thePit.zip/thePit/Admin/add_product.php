<?php
$page_title = 'New Product Form';
$PAGE='prod_form';
$page_css = 'includes/adminforms.css';
require 'includes/adminhead.php';

if (isset( $_POST['submitted'])){
	require 'ecomplay_connect.php';
	$errors = array(); 
    // validate the product name:
   if (!empty($_POST['pname'])) {
        $pname = escape_data($_POST['pname'], $dbc);
	} else {
        $errors[] = '<p class="error">You forgot to enter the product name!</p>';
	}
	// validate the price:
   if (!empty($_POST['price'])) {
        $price = escape_data($_POST['price'], $dbc);
	} else {
        $errors[] = '<p class="error">You forgot to enter the price!</p>';
	}	
	//validate the category
	if (empty($_POST['category'])) {
        $errors[] = 'You forgot to select the category!';
	} else {
        $category = escape_data($_POST['category'], $dbc);
	}
	
	if (empty($errors)) { // If everything's OK.
			$q = "INSERT INTO products (product_name, category_id, unit_price) 
			VALUES('$pname', '$category', $price)";
			
			$r = @mysqli_query($dbc, $q); //run the query

			if ($r) { // If it ran OK.

				// Print a message:
				echo '<h1>Thank you!</h1>
				<p>The product is registered.</p><p><br></p>';	
				require '../includes/footer.php';

			}		
			mysqli_close($dbc);
			exit();
		} 	else { // Report the errors.
				$message='<h2 class="error">ERROR!</h2>
				<p class="error">The following error(s) occured: <br>';
				foreach ($errors as $msg) { //print the error messages
					$message .= " - $msg<br>\n";
			}
			$message .= "</p<<p>Go back and fill out the form again</p>";
		}
	} // End of if on . . .
?>
    <h1>New Product</h1>
	
  <main>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
      <p class="validation-tip">
	* Indicates a required field.
      </p>
	  
      <fieldset>
        <legend>Enter the product's information in the form:</legend>

	<div class="field">
           <label for="pname">Product Name*: </label>
	   <input type="text" name="pname"  id="pname" 
		  maxlength="100" value="<?php if (isset($_POST['pname'])) echo $_POST['pname']; ?>" autofocus required>
	</div>
	
	<div class="field">
           <label for="price">Price*: </label>
	   <input type="number" name="price"  id="price" step="0.01" placeholder="e.g. 10.50"
		  maxlength="11" value="<?php if (isset($_POST['price'])) echo $_POST['price']; ?>" autofocus required>
	</div>

	
	<?php // an array to represent the categories in the products table
	    $item_array = array('1'=>'Beverages','2'=>'Condiments','3'=>'Confections','4'=>'Dairy Products','5'=>'Grains/Cereals',
	  '6'=>'Meat/Poultry', '7' => 'Produce', '8' => 'Seafood');

	  ?>
	
	<div class="field">
	<label for="category">Category*:</label>
	<select name="category" id="category">
        <option value="">Please choose</option>
		<?php //now output the item array
		// output the array in a foreach loop
			foreach ($item_array as $id => $name){
				echo "<option value=\"$id\""; // \ is used to escape double quotes so the echo statement doesn't end early
				if (isset($_POST['category'])) {
					if ($_POST['category'] == $category) {
						echo ' selected';
					}
				};
				echo ">$name</option>\n";
			}
		?>
	</select>
	</div>
	</fieldset>

    <input type="hidden" name="submitted" value="TRUE">
      <div class="field">
	<button type="submit" class="formButton">Submit New Product</button>
      </div>


</form>
</main>


<div class="container">
			<aside class="sidebar">
				<h2>Relax A Little!</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/7vfjdnQr5I6WjzcxtP5dEt"></iframe>
			</aside>
			</div>

<?php
require '../includes/footer.php';
?>

</body>
</html>
