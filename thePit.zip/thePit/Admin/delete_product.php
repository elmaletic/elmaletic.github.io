<?php 
       $page_title = 'Admin - Delete a Product';
       $short_title = 'Delete a Product';
       $PAGE='deleteproduct';
	   $page_css = 'includes/adminforms.css';
       require 'includes/adminhead.php';

      echo '<h2>Admin - Delete a Product</h2>';

// Check for a valid product ID, through GET or POST:
if ( (isset($_GET['id'])) && (is_numeric($_GET['id'])) ) { // From adminproducts.php
	$id = $_GET['id'];
} elseif ( (isset($_POST['id'])) && (is_numeric($_POST['id'])) ) { // Form submission.
	$id = $_POST['id'];
} else { // No valid ID, kill the script.
	echo '<p class="error">This page has been accessed in error.</p>';
	include '../includes/footer.php'; 
	exit();
}

require 'ecomplay_connect.php';

// Check if the form has been submitted:
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	if ($_POST['sure'] == 'Yes') { // Delete the record.

		// Make the query:
		$q = "DELETE FROM products WHERE product_id = $id LIMIT 1";
		$r = @mysqli_query($dbc,$q);

		if (mysqli_affected_rows($dbc) == 1) { // If it ran OK.

			// Print a message:
			echo '<p>The product has been deleted.</p>';	

		} else { // If the query did not run OK.
			echo '<p class="error">The product could not be deleted due to a system error.</p>'; // Public message.
			echo '<p>' . mysqli_error($dbc) . '<br>Query: ' . $q . '</p>'; // Debugging message.
		}
	
	} else { // Indicate product NOT deleted.
		echo '<p>The product has NOT been deleted.</p>';	
	}

} else { // Show the form.

	// Retrieve the product's information:
	$q = "SELECT product_name FROM products WHERE product_id=$id";
	$r = @mysqli_query($dbc,$q);
	
        if (mysqli_num_rows($r) == 1) { // Valid product ID, show the form.
			// load product info
			$row = mysqli_fetch_array($r,MYSQLI_NUM);


			// Display the record being deleted:
			echo "<h3 class='out'>Product Name: $row[0]</h3>
			Are you sure you want to delete this product?";
?>



     <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

	 <div class="field">
	   Yes: <input type="radio" id="sure" name="sure" value="Yes"> 
	   No: <input type="radio" name="sure" value="No" checked="checked">
         </div>


	 <div class="field">
           <button type="submit" class="formButton">Delete Product</button>
	 </div>
	 <input type="hidden" name="id" value="<?php echo $id; ?>">
     </form>


	<?php	
	} else { // Not a valid product ID.
		echo '<p class="error">This page has been accessed in error.</p>';
	}

} // END of the main submission conditional -- END if ($_SERVER['REQUEST_METHOD'] == 'POST') {

mysqli_close($dbc);

?>

	<div class="container">
		<aside class="sidebar">
			<h2>Relax A Little!</h2>
			<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/7vfjdnQr5I6WjzcxtP5dEt"></iframe>
		</aside>
	</div>
<?php
require '../includes/footer.php';
?>
</body>
</html>
