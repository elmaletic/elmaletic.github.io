<?php
//PLACEHOLDER FOR ADMIN LOGIN
//CODE TAKEN FROM login.php FOR CUSTOMERS
//NOT FUNCTIONING FOR ADMINS!!!
$page_title = 'Admin Login';
$PAGE='login';
$page_css = 'includes/adminforms.css';
require 'includes/adminhead.php';

	if (isset( $_POST['submitted'])){
		require 'ecomplay_connect.php';
		$errors = array(); 
	// validate the email:
   if (!empty($_POST['email'])) {
        $email = escape_data($_POST['email'], $dbc);
	} else {
        $errors[] = '<p class="error">You forgot to enter your email!</p>';
	}
	// validate the password:
    if (!empty($_POST['password'])) {
         $pass = escape_data($_POST['password'], $dbc);
	} else {
         $errors[] = '<p class="error">You forgot to enter your password!</p>';
	}
	
	if (empty($errors)) { // If everything's OK.
		//mysql query
		//$r = @mysqli_query($dbc, $q); //run the query
		//if ($r) { // If it ran OK.
		// Print a message:
				echo '<h1>Thank you!</h1>
				<p>You are now logged in.</p><p><br></p>';	
				require '../includes/footer.php';

			//}	
			mysqli_close($dbc);
			exit();
			}
		 	else { // Report the errors.
				$message='<h2 class="error">ERROR!</h2>
				<p class="error">The following error(s) occured: <br>';
				foreach ($errors as $msg) { //print the error messages
					$message .= " - $msg<br>\n";
			}
			$message .= "</p<<p>Go back and fill out the form again</p>";
		}
	} // End of if on . . .
?>
    <h1>Login:</h1>
	
	
  <main>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
   	<div class="field">
	   <label for="email">Email*:</label>
	   <input type="email" name="email"  id="email"
		  placeholder="e.g. jdoe@lakers.mercyhurst.edu" value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>" required>
        </div>
		
	<div class="field">
	   <label for="password">Password*:</label>
	   <input type="password" id="password" name="password" maxlength="19"
	   value="<?php if (isset($_POST['password'])) echo $_POST['password']; ?>" required>
	</div>

    <input type="hidden" name="submitted" value="TRUE">
      <div class="field">
	<button type="submit" class="formButton">Log In</button>
      </div>


</form>
</main>


<div class="container">
			<aside class="sidebar">
				<h2>Relax A Little!</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/7vfjdnQr5I6WjzcxtP5dEt"></iframe>
			</aside>
</div>

<?php
require '../includes/footer.php';
?>

</body>
</html>
