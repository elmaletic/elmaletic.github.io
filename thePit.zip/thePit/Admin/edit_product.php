<?php 
       $page_title = 'Admin -  Edit a Product';
       $short_title = 'Edit a Product';
       $PAGE='productedit';
	   $page_css = 'includes/adminforms.css';
       require 'includes/adminhead.php';
      echo '<h2>Admin - Edit a Product</h2>';

// Check for a valid product ID, through GET or POST:
if ( (isset($_GET['id'])) && (is_numeric($_GET['id'])) ) { // From adminproducts.php
	$id = $_GET['id'];
} elseif ( (isset($_POST['id'])) && (is_numeric($_POST['id'])) ) { // Form submission.
	$id = $_POST['id'];
} else { // No valid ID, kill the script.
	echo '<p class="error">This page has been accessed in error.</p>';
	require '../includes/footer.php';
	exit();
}

        require 'ecomplay_connect.php';


// Check if the form has been submitted:
if (isset($_POST['submitted'])) {

	$errors = array();

	// Check for a product name:
	if (empty($_POST['pname'])) {
		$errors[] = 'You forgot to enter the product name.';
	} else {
		$pname = escape_data($_POST['pname'], $dbc);
	}

	// Check for a price:
	if (empty($_POST['price'])) {
		$errors[] = 'You forgot to enter the price.';
	} else {
		$price = escape_data($_POST['price'], $dbc);
	}

	// Check for a category:
	if (empty($_POST['category'])) {
		$errors[] = 'You forgot to select the category.';
	} else {
		$category = escape_data($_POST['category'], $dbc);
	}

	if (empty($errors)) { // If everything's OK.
		$q = "SELECT product_id FROM products WHERE product_name = '$pname' AND product_id != $id";
		$r = @mysqli_query($dbc,$q);
		if (mysqli_num_rows($r) == 0) {
			// Make the query:
              $q = "UPDATE products SET product_name='$pname', unit_price=$price, category_id ='$category'
                    WHERE product_id=$id LIMIT 1";
              $r = @mysqli_query ($dbc, $q);
			  if (mysqli_affected_rows($dbc) == 1) { // If it ran OK.

					// Print a message:
                    echo '<p>The product has been edited.</p>';

              } else { // If it did not run OK.
                    // Public message.
                    echo '<p class="error">Either no changes were made OR the
                    product could not be edited due to a system error.
                    We apologize for any inconvenience.</p>';
                    // Debugging message.
                    echo '<code>' . mysqli_error($dbc) . '<br>
					Query: ' . $q . '</code><br>';
              }



        } else { // Already registered.
           echo '<p class="error">The product has already been registered.</p>';
        }  // END if (mysqli_num_rows($r) == 0)   IF

	} else { // Report the errors.

		echo '<p class="error">The following error(s) occurred:<br>';
		foreach ($errors as $msg) { // Print each error.
			echo " - $msg<br>\n";
		}
		echo '</p><p>Please try again.</p>';

	} // End of if (empty($errors)) IF.

} // End of submit conditional.

   // Retrieve the product's information:
   $q = "SELECT product_name, unit_price, category_id FROM products WHERE product_id=$id";
   $r = @mysqli_query($dbc, $q);

   if (mysqli_num_rows($r) == 1) { // Valid product ID, show the form.
	$row = mysqli_fetch_array($r,MYSQLI_NUM);
	// print '<pre>'.print_r($row,1).'</pre>'; //prints out the array and each row. v helpful
?>


<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
    <fieldset>
         <legend>Edit the Product Information</legend>

         <div class="field">
           <label for="pname">Product Name:</label>
           <input type="text" name="pname"  maxlength="100" id="pname" value="<?php echo $row[0]?>">
           </div>
         <div class="field">
           <label for="price">Price:</label>
           <input type="number" name="price"  id="price" step="0.01" maxlength="11" value="<?php echo $row[1]?>">
         </div>
		 
		 <?php // an array to represent the categories in the products table
		 $item_array = array('1'=>'Beverages','2'=>'Condiments','3'=>'Confections','4'=>'Dairy Products','5'=>'Grains/Cereals',
		'6'=>'Meat/Poultry', '7' => 'Produce', '8' => 'Seafood');
		?>
		 
         <div class="field">
           <label for="category">Category:</label>
		   <select name="category" id="category">
           <option value="">Please choose</option>
		   <?php //now output the states array
		   // output the array in a foreach loop
			foreach ($item_array as $item => $name){
				echo "<option value=\"$item\""; // \ is used to escape double quotes so the echo statement doesn't end early
				if (isset($_POST['category'])) {
					if ($_POST['category'] == $category) {
						echo ' selected';
					}
				};
				echo ">$name</option>\n";
			}
		?>
	</select>
         </div>
         <input type="hidden" name="id" value="<?php echo $id; ?>">
    </fieldset>
    <div class="field">
          <button type="submit" class="formButton">Edit Product</button>
    </div>
	<input type="hidden" name="submitted" value="TRUE">
</form>


<?php

} else { // Not a valid product ID.
	echo '<p class="error">This page has been accessed in error.</p>';
}

mysqli_close($dbc);

?>

	<div class="container">
		<aside class="sidebar">
			<h2>Relax A Little!</h2>
			<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/7vfjdnQr5I6WjzcxtP5dEt"></iframe>
		</aside>
	</div>
<?php
require '../includes/footer.php';
?>
</body>
</html>
