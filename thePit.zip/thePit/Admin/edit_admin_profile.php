<?php 
//PLACEHOLDER FOR EDITING ADMIN PROFILE
//CODE TAKEN FROM editprofile.php FOR CUSTOMERS
//NOT FUNCTIONING FOR ADMINS!!!
       $page_title = 'Admin - Edit Profile';
       $short_title = 'Edit Profile';
       $PAGE='adminprofile';
	   $page_css = 'includes/adminforms.css';
       require 'includes/adminhead.php';
      echo '<h2>User - Edit Profile</h2>';

/* Check for a valid user ID, through GET or POST:
if ( (isset($_GET['id'])) && (is_numeric($_GET['id'])) ) { 
	$id = $_GET['id'];
} elseif ( (isset($_POST['id'])) && (is_numeric($_POST['id'])) ) { // Form submission.
	$id = $_POST['id'];
} else { // No valid ID, kill the script.
	echo '<p class="error">This page has been accessed in error.</p>';
	require 'includes/footer.php';
	exit();
} */

        require 'ecomplay_connect.php';


// Check if the form has been submitted:
if (isset($_POST['submitted'])) {

	$errors = array();

	// Check for a first name:
	if (empty($_POST['firstname'])) {
		$errors[] = 'You forgot to enter your first name.';
	} else {
		$fn = escape_data($_POST['firstname'], $dbc);
	}

	// Check for a last name:
	if (empty($_POST['lastname'])) {
		$errors[] = 'You forgot to enter your last name.';
	} else {
		$ln = escape_data($_POST['lastname'], $dbc);
	}

	// Check for an email address:
	if (empty($_POST['email'])) {
		$errors[] = 'You forgot to enter your email address.';
	} else {
		$e = escape_data($_POST['email'], $dbc);
	}
	
	// validate the phone number:
   if (!empty($_POST['phone'])) {
        $phone = escape_data($_POST['phone'], $dbc);
	} else {
        $errors[] = '<p class="error">You forgot to enter your phone number!</p>';
	} 
	// validate the address:
   if (!empty($_POST['address'])) {
        $address = escape_data($_POST['address'], $dbc);
	} else {
        $errors[] = '<p class="error">You forgot to enter your address!</p>';
	} 
	// validate the city:
   if (!empty($_POST['city'])) {
        $city = escape_data($_POST['city'], $dbc);
	} else {
        $errors[] = '<p class="error">You forgot to enter your city!</p>';
	} 
	//validate the state
	if (empty($_POST['state'])) {
        $errors[] = 'You forgot to enter the state.';
	} else {
        $state = escape_data($_POST['state'], $dbc);
	}
	// validate the zipcode:
   if (!empty($_POST['zip'])) {
        $zip = escape_data($_POST['zip'], $dbc);
	} else {
        $errors[] = '<p class="error">You forgot to enter your zip code!</p>';
	} 

	if (empty($errors)) { // If everything's OK.
		/* $q = "SELECT cust_id FROM customers WHERE email = '$e' AND cust_id != $id";
		$r = @mysqli_query($dbc,$q);
		if (mysqli_num_rows($r) == 0) {
			// Make the query:
              $q = "UPDATE customers SET first_name='$fn', last_name='$ln', email='$e'
                    WHERE cust_id=$id LIMIT 1";
              $r = @mysqli_query ($dbc, $q);
			  if (mysqli_affected_rows($dbc) == 1) { // If it ran OK. */

					// Print a message:
                    echo '<p>The user has been edited.</p>';

             /* } else { // If it did not run OK.
                    // Public message.
                    echo '<p class="error">Either no changes were made OR the
                    user could not be edited due to a system error.
                    We apologize for any inconvenience.</p>';
                    // Debugging message.
                    echo '<code>' . mysqli_error($dbc) . '<br>
					Query: ' . $q . '</code><br>';
              }



        } else { // Already registered.
           echo '<p class="error">The email address has already been registered.</p>';
        }  // END if (mysqli_num_rows($r) == 0)   IF */

	} else { // Report the errors.

		echo '<p class="error">The following error(s) occurred:<br>';
		foreach ($errors as $msg) { // Print each error.
			echo " - $msg<br>\n";
		}
		echo '</p><p>Please try again.</p>';

	} // End of if (empty($errors)) IF.

} // End of submit conditional.

   /* // Retrieve the user's information:
   $q = "SELECT first_name, last_name, email, phone, street, city, state, zip FROM customers WHERE cust_id=$id";
   $r = @mysqli_query($dbc, $q);

   if (mysqli_num_rows($r) == 1) { // Valid user ID, show the form.
	$row = mysqli_fetch_array($r,MYSQLI_NUM);
	// print '<pre>'.print_r($row,1).'</pre>'; //prints out the array and each row. v helpful */
?>

<main>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
    <fieldset>
         <legend>Edit Your Information (please fill out everything, even if there are no changes):</legend>

         <div class="field">
           <label for="fname">First Name:</label>
           <input type="text" name="firstname"  id="fname"> <!-- value < ? php echo $row[0]?> -->
           </div>
         <div class="field">
           <label for="lname">Last Name:</label>
           <input type="text" name="lastname"  id="lname" maxlength="30">
         </div>
         <div class="field">
           <label for="email">Email:</label>
           <input type="email" name="email"  id="email" maxlength="60">
         </div>
		 <div class="field">
           <label for="phone">Phone Number:</label>
		   <input type="tel" id="phone" name="phone" maxlength="12" placeholder="e.g. 555-555-5555" 
		   pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" title="Please format the number as such: 555-555-5555">
         </div>
		 <div class="field">
           <label for="address">Street Address:</label>
		   <input type="text" id="address" name="address" maxlength="100" placeholder="e.g. 123 Main Street">
         </div>
		 <div class="field">
		   <label for="city">City:</label>
		   <input type="text" id="city" name="city" maxlength="100" placeholder="e.g. Pittsburgh">
         </div>
		 
		<?php // an array containing all 50 states plus DC
	    $state_array = array('AL'=>'Alabama','AK'=>'Alaska','AZ'=>'Arizona','AR'=>'Arkansas','CA'=>'California',
	    'CO'=>'Colorado','CT'=>'Connecticut','DE'=>'Delaware','DC'=>'D.C.','FL'=>'Florida','GA'=>'Georgia',
	    'HI'=>'Hawaii','ID'=>'Idaho','IL'=>'Illinois','IN'=>'Indiana','IA'=>'Iowa','KS'=>'Kansas','KY'=>'Kentucky',
	    'LA'=>'Louisiana','ME'=>'Maine','MD'=>'Maryland','MA'=>'Massachusetts','MI'=>'Michigan','MN'=>'Minnesota',
	    'MS'=>'Mississippi','MO'=>'Missouri','MT'=>'Montana','NE'=>'Nebraska','NV'=>'Nevada','NH'=>'New Hampshire',
	    'NJ'=>'New Jersey','NM'=>'New Mexico','NY'=>'New York','NC'=>'North Carolina','ND'=>'North Dakota',
	    'OH'=>'Ohio','OK'=>'Oklahoma','OR'=>'Oregon','PA'=>'Pennsylvania','RI'=>'Rhode Island',
	    'SC'=>'South Carolina','SD'=>'South Dakota','TN'=>'Tennessee','TX'=>'Texas','UT'=>'Utah','VT'=>'Vermont',
	    'VA'=>'Virginia','WA'=>'Washington','WV'=>'West Virginia','WI'=>'Wisconsin','WY'=>'Wyoming');
	  ?>
		 
		 <div class="field">
		   <label for="state">State:</label>
		   <select name="state" id="State">
		   <option value="">Please choose</option>
		   <?php
			foreach ($state_array as $id => $name){
				echo "<option value=\"$id\">$name</option>\n"; 
			}
			?>
		   </select>
         </div>
		 <div class="field">
		   <label for="zip">ZIP Code:</label>
		   <input type="text" id="zip" name="zip">
         </div>
         <!-- <input type="hidden" name="id" value="<?php echo $id; ?>"> -->
    </fieldset>
    <div class="field">
          <button type="submit" class="formButton">Update Information</button>
    </div>
	<input type="hidden" name="submitted" value="TRUE">
</form>
</main>

<div class="container">
			<aside class="sidebar">
				<h2>Relax A Little!</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/7vfjdnQr5I6WjzcxtP5dEt"></iframe>
			</aside>
			</div>


<?php
require '../includes/footer.php';
?>

</body>
</html>