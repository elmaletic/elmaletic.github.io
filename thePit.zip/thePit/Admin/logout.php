<?php
//PLACEHOLDER FOR ADMIN LOGOUT
//NOT FUNCTIONING FOR ADMINS!!!
$page_title = 'Admin Logout';
$PAGE='logout';
$page_css = 'includes/adminforms.css';
require 'includes/adminhead.php';
?>

<h1> Are you sure you want to logout?</h1>

 <main>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
   	<div class="field">
		<input type="radio" id="yes" name = "confirm" value = "yes">
			<label for="yes" class="radios">Yes</label>
		<input type="radio" id="no" name = "confirm" value = "no" checked>
			<label for="no" class = "radios">No</label>
	</div>
	</div>

    <input type="hidden" name="submitted" value="TRUE">
      <div class="field">
	<button type="submit" class="formButton">Log Out</button>
      </div>


</form>
</main>


<div class="container">
			<aside class="sidebar">
				<h2>Relax A Little!</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/7vfjdnQr5I6WjzcxtP5dEt"></iframe>
			</aside>
</div>

<?php
require '../includes/footer.php';
?>

</body>
</html>