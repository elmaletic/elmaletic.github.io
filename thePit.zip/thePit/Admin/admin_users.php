<?php 
    // require_once 'includes/config.inc.php'; #GOOD TO USE IN PLACE OF META CONTENT IN HEADER 

    $page_title = 'View the Current Users';
    $short_title='Admin: Current Users';
    $PAGE='adminusers';
	$page_css='includes/admintables.css';
    require 'includes/adminhead.php';

// Page header:
echo '<h2>Registered Users</h2>';

require 'ecomplay_connect.php'; //connect to the db 


//the number of records to display on a page
		$display = 20;
		
		// Determine how many pages there are...
		if (isset($_GET['p']) && is_numeric($_GET['p'])) { // Already been determined.
			$pages = $_GET['p'];
		} else { // Need to determine.
			// Count the number of records:
			$q = "SELECT COUNT(cust_id) FROM customers";
			$r = @mysqli_query ($dbc, $q);
			$row = @mysqli_fetch_array ($r, MYSQLI_NUM);
			$records = $row[0];

			// Calculate the number of pages...
			if ($records > $display) {    // More than 1 page.
				$pages = ceil ($records/$display); //ceiling - next integer up (rounded) whereas floor is next integer down.
			} else {
				$pages = 1;
			}
		} // END   (isset($_GET['p'])   IF.
		
		// Determine where in the database to start returning results...
		if (isset($_GET['s']) && is_numeric($_GET['s'])) {
			$start = $_GET['s'];
		} else {
			$start = 0;
		}
		
		// Determine the sort and order   
		// Default is by registration date and asc.
		$order = (isset($_GET['order'])) ? $_GET['order'] : 'rd';
		$sort = (isset($_GET['sorting'])) ? $_GET['sorting'] : 'bottom';
		
		//switch from asc to desc by clicks. 
		//IS NOT CONTINOUS -- WHEN GOING TO ANOTHER PAGE, ORDER REVERSES
		switch ($sort){
			case 'bottom':
				$defaultsort='ASC';
				break;
			case 'top':
				$defaultsort = 'DESC';
				break;
			default:
				$defaultsort = 'ASC';
				$sort = 'bottom';
				break;
		}
		
		if(isset($_GET['sorting']))
		{
			if($_GET['sorting']=='ASC')
		{
			$defaultsort='DESC';
		}
		else
		{
			$defaultsort='ASC';
		}
		}

		
		// Determine the sorting order:
		switch ($order) {
			case 'ln':
					$order_by = 'last_name';
					break;
			case 'fn':
					$order_by = 'first_name';
					break;
			case 'rd':
					$order_by = 'date_created';
					break;
			default:
					$order_by = 'date_created';
					$order = 'rd';
					break;
		}
		
		if($order_by == 'first_name'){
			$active1 = 'active';
			$active2='notactive';
			$active3='notactive';
		}
		else if($order_by == 'last_name'){
			$active2 = 'active';
			$active3='notactive';
			$active1='notactive';
		}
		else{
			$active3='active';
			$active1='notactive';
			$active2='notactive';
		}


//make the query
$q = "select first_name, last_name, 
	 date_format(date_created, '%M %d, %Y') as dr, cust_id from customers 
	 order by $order_by $defaultsort LIMIT $start, $display";
	 
$r = @mysqli_query($dbc,$q);


$num = mysqli_num_rows($r);

if ($num > 0) { // If it ran OK, display the records.

// Table header:
        echo '<table class="adminUsers">
         <colgroup>
           <col id="edit"><col id="delete"><col id="fname"><col id="lname"><col id="date">
        </colgroup>
        <thead>
             <tr>
                 <th>Edit</th>
                 <th>Delete</th>
                 <th><a class="' . $active1 . '" href="admin_users.php?sorting='.$defaultsort.'&amp;order=fn">First Name</a></th>
                 <th><a class="' . $active2 . '" href="admin_users.php?sorting='.$defaultsort.'&amp;order=ln">Last Name</a></th>
                 <th><a class="' . $active3 . '" href="admin_users.php?sorting='.$defaultsort.'&amp;order=rd">Date Registered</a></th>
              </tr>
        </thead>
        <tbody>
';
    // Fetch and print all the records:
      while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
		echo '<tr>
				<td><a href="edit_user.php?id='.$row['cust_id'].'">Edit</a></td>
				<td><a href="delete_user.php?id='.$row['cust_id'].'">Delete</a></td>
				<td>' . $row['first_name'] . '</td>
				<td>' . $row['last_name'] . '</td>
				<td>' . $row['dr'] . '</td>
			  </tr>';

      }  // END the  while ($row = mysqli_fetch_array()  loop    
		
	echo "\n</tbody>\n
     </table>\n";
	 
	
	mysqli_free_result($r);

 } else { // If no records were returned.
   echo '<p class="error">There are currently no registered users.</p>';
 } // END if ($num > 0)  IF

mysqli_close($dbc);

// Make the links to other pages, if necessary.
       if ($pages > 1) {

           // Add some spacing and start a paragraph:
           echo '<br><p class="out">';

           // Determine what page the script is on:
           $current_page = ($start/$display) + 1;

           // If it's not the first page, make a Previous link:
  if ($current_page != 1) {
                echo '<a href="admin_users.php?s=' . ($start - $display) .
		     '&amp;p=' . $pages . '&amp;sorting='.$sort.'&amp;order=' . $order . '">Previous</a> &nbsp;';
	    }
	    
	    // Make all the numbered pages:
	    for ($i = 1; $i <= $pages; $i++) {
                if ($i != $current_page) {
		    echo '&nbsp; <a href="admin_users.php?s=' . (($display * ($i - 1))) .
			  '&amp;p=' . $pages . '&amp;sorting='.$sort.'&amp;order=' . $order . '">' . $i . '</a> &nbsp;';
                } else {
                        echo '&nbsp;   ' . $i . ' ';
                }
		
	    } // End of FOR loop.
        
	    // If it's not the last page, make a Next button:
	    if ($current_page != $pages) {
		echo '&nbsp; <a href="admin_users.php?s=' . ($start + $display) .
		   '&amp;p=' . $pages . '&amp;sorting='.$sort.'&amp;order=' . $order . '">Next</a>';
	    }
	
	  echo '</p>'; // Close the paragraph
        } // End of if($pages)  links section.
		
//NO SIDEBAR SO THE TABLE CAN USE THE ENTIRE WIDTH OF THE CONTENT
//SIDEBAR GETS PUSHED TO THE BOTTOM, AND IT ALSO LOOKS BETTER W/O A SIDEBAR

require '../includes/footer.php';
?>

</body>
</html>
