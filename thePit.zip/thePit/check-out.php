<?php
$page_title = 'Check Out';
$PAGE='checkout';
require 'includes/header.php';
?>

<h1> Your Order:</h1>
<main>

</main>
<div class="container">
			<aside class="sidebar">
				<h2>Relax A Little!</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/7vfjdnQr5I6WjzcxtP5dEt"></iframe>
			</aside>
			</div>

<?php
require 'includes/footer.php';
?>

</body>
</html>