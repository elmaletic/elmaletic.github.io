<?php       
    $page_title = 'Chiodos';
    $PAGE='Chiodos';
    require 'includes/header.php';
?> 
	  
	  
          <h1 id ="top">"It's our time to really do things right."</h1>

          <main>
			
			<section class="content">
			  <br>
			  <h2><a href="chiodos">Chiodos</a></h2>
			  <br>
			  <img src="http://via.placeholder.com/200x200">
			  <p> Fronted by Craig Owens for every album except <i>Illuminaudio</i>, Chiodos quickly became one of
				the biggest bands in the post-hardcore scene. Even though they parted ways in 2015, after the release
				of <i>Devil</i>, Chiodos has made a tremendous impact on scene kids everywhere (and yes, we're also
				referring to ourselves because once a scene kid, always a scene kid) and we decided to keep selling 
				their merch so they never die.
			  </p>
			</section>
          </main>
		  
		  
		   <div class="container">
			<aside class="sidebar">
				<h2>What We're Jamming To:</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/0tnnf548YZPUCqhzKZfH4a"></iframe>
			</aside>
			</div>
		  
		
  
    <footer>
	<?php
	include 'includes/footer.php';
	?>
    </footer>
    </div> 

  </body>
</html>