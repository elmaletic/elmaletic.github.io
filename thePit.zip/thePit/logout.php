<?php # the Pit - logout.php
    // This is the logout page for the site.
    require 'includes/config.inc.php';
	require 'includes/functions.php';
    $page_title = 'Logout';
    $PAGE='login';
    require 'includes/header.php';

// If no first_name session variable exists, redirect the user:
if (!isset($_SESSION['first_name'])) {

	redirect_user('index.php');

} else { // Log out the user.

	$_SESSION = array(); // Destroy the variables.
	session_destroy(); // Destroy the session itself.
	setcookie (session_name('thePit'), '', time()-3600); // Destroy the cookie.

}

// Print a customized message:
echo '<h3>Thank you for shopping at The Pit!
<br>
You are now logged out.</h3>';

include 'includes/footer.php';
?>
