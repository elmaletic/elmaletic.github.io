<?php       
    $page_title = 'Envy on the Coast';
    $PAGE='EOTC';
    require 'includes/header.php';
?>
	  
          <h1 id ="top">"Please bring me back to you."</h1>

          <main>
			
			<section class="content">
			  <br>
			  <h2><a href="eotc">Envy on the Coast</a></h2>
			  <br>
			  <img src="http://via.placeholder.com/200x200">
			  <br>
			  <p> Switching over to the more "chill" music, Envy on the Coast is a great underground band to keep track of.
				Outside of being popular among hipsters in the Northeast of America, Envy on the Coast offers very real lyrics
				and some pretty toe-tapping tunes. Bonus: tickets to see this band won't put you back $100!
			  </p>
			</section>
          </main>
		  
		  
		   <div class="container">
			<aside class="sidebar">
				<h2>What We're Jamming To:</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/0tnnf548YZPUCqhzKZfH4a"></iframe>
			</aside>
			</div>
		  
		
  
    <footer>
	<?php
	include 'includes/footer.php';
	?>
    </footer>
    </div> 

  </body>
</html>