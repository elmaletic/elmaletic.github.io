    <?php if (!isset($PAGE) ) {$PAGE='home';} ?> 
      <nav class="<?php echo $PAGE; ?>">
    <div class="navbar">
		<nav>
			<a href="index.php">Home</a>
			<div class="dropdown">
				<button class="dropbtn">Artists 
					<i class="fa-fa-caret-down"></i> 
				</button>
			<div class="dropdown-content">
				<a href="chiodos.php">Chiodos</a>
				<a href="dgd.php">Dance Gavin Dance</a>
				<a href="eotc.php">Envy on the Coast</a>
				<a href="flor.php">Flor</a>
				<a href="ll.php">letlive.</a>
				<a href="nothing.php">Nothing More</a>
			</div>
			</div> 
			<a href="products.php">Products</a>
			<a href="<?php echo (isset($_SESSION['cust_id']))
            ? 'shopping-cart.php">Cart' : 'new_customer.php">New Customer?';?></a>
			<a href="<?php echo (isset($_SESSION['cust_id']))
            ? 'check-out.php">Checkout' : '">';?></a>
			<div class="dropdown">
				<button class="dropbtn">Returning Customer
					<i class="fa-fa-caret-down"></i>
				</button>
			<div class="dropdown-content">
			<a href="<?php echo (isset($_SESSION['cust_id']))
            ? 'logout.php">Logout' : 'customer_login.php">Login';?></a>
			<a href="<?php echo (isset($_SESSION['cust_id'])) ?
            'change_password.php">Change Password' : 'forgot_password.php">Forgot Password';?></a>
			<a href="<?php echo (isset($_SESSION['cust_id'])) ?
			'edit_profile.php">Edit Profile' : '">';?></a>
			</div>
			</div>
	</div>
		</nav> 