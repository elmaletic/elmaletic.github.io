<?php #  the Pit

      // Flag variable for site status:
      define('LIVE', FALSE); // set False (this one)  when still developing the site
      ##  define('LIVE', TRUE); 

      // Admin contact address:
       define('EMAIL', 'eletic40@lakers.mercyhurst.edu');

      define ('BASE_URL',  'http://math.mercyhurst.edu/~eletic/projects/thePit/');

      // Location of the MySQL connection script:
	  
	  define('db', 'ecomplay_connect.php');

// Function for handling errors.
      // Takes five arguments: 1) error number, 2) error message (string),
      // 3) name of the file where the error occurred (string)
      // 4) line number where the error occurred,
      // 5) the variables that existed at the time (array).

function my_error_handler ($e_number, $e_message, $e_file, $e_line, $e_vars) {

        // Build the error message.
        $message = "<p>An error occurred in script '$e_file' on line $e_line:\n<br> $e_message\n<br>";

        // Add the date and time:
        $message .= "Date/Time: " . date('n-j-Y H:i:s') . "\n<br>";

        // Append $e_vars to the $message:
        $message .= "<pre>" . print_r ($e_vars, 1) . "</pre>\n</p>";

        if (!LIVE) { // Development (print the error).

                echo '<div class="error">' . nl2br($message) . '</div><br>';

        } else { // Don't show the error:

                // Send an email to the admin:
                mail(EMAIL, 'The Pit PHP Error!', $message, 'From: eletic40@lakers.mercyhurst.edu');

                // Only print an error message if the error isn't a notice:
                if ($e_number != E_NOTICE) {
                        echo '<div class="error">A system error occurred. We apologize for the inconvenience.</div><br>';
                }
        } // End of !LIVE IF-ELSE.

	return true; // So that PHP doesn't try to handle the error, too.

} // End of my_error_handler() definition.

      // Use my error handler
      set_error_handler ('my_error_handler');