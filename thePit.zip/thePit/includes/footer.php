<div class="box">
	  
	<div class="box1">
	<h2> About <i>The Pit</i></h2>
	<p><i>The Pit</i> offers a place for people interested in rock/alternative rock/post-hardcore groups to shop.
	Although we are just starting out, we plan on adding many more &#34;underground&#34; bands.
	Sure, there are sites like <i>MerchNow</i> and <i>MerchDirect</i>, but neither of those sites offer a wide enough variety for people that listen to
	bands that are more underground and have different sounds outside the normal rock or metal sound.
	Plus, we have free shipping on every order over $5, and just remember that no other pit is as safe as <i>The Pit</i>.
	</p>
	</div>
	
	<div class="box2">
	<h2>Follow Us</h2>
	<p><a href="https://www.facebook.com/danceelmadance">f</a>
	<a href="https://www.instagram.com/cheeohdohz">i</a>
	<a href="https://open.spotify.com/user/1237657570/playlist/3Eg5BLm35JpwpDt4WbX2pO">s</a>
	</p>
	</div>
	
	<div class="box3">
	<p><a href="#top"> Go back to the top</a>
	<br>
	<br>
	Interested in subscribing to a music newsletter? <a href="../../interests/music/music_form.html"> Click here!</a>
	<br>
	<br>
	&#34;Keep listening to music, because it gets you through everything, I promise.&#34; 
	<br>
	- Mitch Lucker
	</p>
	</div>
	  
	</div>
<footer>
	<p>© 2018 The Pit. All rights reserved.
	If you have questions, <a href="mailto:eletic40@lakers.mercyhurst.edu">Contact Us</a>.</p>	
</footer>

<?php // Flush the buffered output.
ob_end_flush();

?>