<?php
	//output buffering
	ob_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	 <title> <?php
			echo $page_title;
		?></title>
	<meta name="description" content="Learning PHP, Mercyhurst University">
    <meta name="author" content="Elma Letic">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="includes/pit.css"> 
	
	<?php
	if (isset($page_css)){
      echo '   <link type="text/css" rel="stylesheet" href="'.$page_css.'">';
   }
   ?>

</head>
<body>

	<header class="masthead">	  
		<img src="images/pit.jpg" alt="Gritty spotlight that says 'The Pit' and 'Where Rebellion Thrives'">
		
	<div id="wrapper">     
		<?php  include('nav.php'); ?>
      
		</header><!-- end masthead -->
    
		<div class="container">