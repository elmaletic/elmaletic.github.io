<?php       
    $page_title = 'Welcome to The Pit';
    $PAGE='home';
	require_once 'includes/config.inc.php';
    require 'includes/header.php';
?>
	      <h1 id ="top">Check Out Our Artists:</h1>
		  <?php
		  echo  (isset($_SESSION['first_name'])) ? '<h3>Welcome '. $_SESSION['first_name'] .'</h3>' : '';
		  ?>

          <main>
			
			<section class="content">
			  <br>
			  <h2><a href="chiodos.php">Chiodos</a></h2>
			  <br>
			  <img src="images/chiodos.jpg" height="200px" width="200px">
			  <p> Fronted by Craig Owens for every album except <i>Illuminaudio</i>, Chiodos quickly became one of
				the biggest bands in the post-hardcore scene. Even though they parted ways in 2015, after the release
				of <i>Devil</i>, Chiodos has made a tremendous impact on scene kids everywhere (and yes, we're also
				referring to ourselves because once a scene kid, always a scene kid) and we decided to keep selling 
				their merch so they never die.
			  </p>
			  <br>
			  <h2><a href="dgd.php">Dance Gavin Dance</a></h2>
			  <br>
			  <img src="images/dgd.jpg" height="200px" width="200px">
			  <br>
			  <p> Although Dance Gavin Dance has gone through multiple line-up changes, they have still maintained to
				keep lovers of the hardcore scene hooked on them. Between their chaotic album covers, strange lyrics,
				and progressive elements, they never fail to impress (although we would really like to see Jonny back!).
			  </p>
			  <br>
			  <h2><a href="eotc.php">Envy on the Coast</a></h2>
			  <br>
			  <img src="images/eotc.jpg" height="200px" width="200px">
			  <br>
			  <p> Switching over to the more "chill" music, Envy on the Coast is a great underground band to keep track of.
				Outside of being popular among hipsters in the Northeast of America, Envy on the Coast offers very real lyrics
				and some pretty toe-tapping tunes. Bonus: tickets to see this band won't put you back $100!
			  </p>
			  <br>
			  <h2><a href="flor.php">Flor</a></h2>
			  <br>
			  <img src="images/Flor.jpg" height="200px" width="200px">
			  <br>
			  <p> The Spanish word for "flower," Flor -- much like Envy on the Coast -- offers a variety of chill beats and 
				relaxing music. It might be hard to get into at first, but trust us, after your third or fourth listen,
				you'll be getting their songs stuck in your head for days to come!
			  </p>
			  <br>
			  <h2><a href="ll.php">letlive.</a></h2>
			  <br>
			  <img src="images/ll.jpg" height="200px" width="200px">
			  <br>
			  <p> On the heavier side of things comes letlive. Very political and high-energy, letlive. might be the perfect band
				to listen to after a break-up or just during a gym workout. One thing is for certain, though: Jason Butler's voice
				cannot be beat in the hardcore scene. (And before you ask, yes, the band name is actually stylized like that.)
			  </p>
			  <h2><a href="nothing.php">Nothing More</a></h2>
			  <br>
			  <img src="images/nothing.jpg" height="200px" width="200px">
			  <br>
			  <p> Nothing More has been around for a while, but they recently got nominated for a Grammy which should signal how 
				good this band is, even if they didn't win the Grammy. Fans seem to disagree on if they're consider progressive rock
				or progressive metal, but either way Nothing More definitely proves the point that rock and roll is not dead. 
				Whether they're proggy metal or proggy rock, we'll let you decide. :)
			  </p>
			</section>
          </main>
		  
		  
		   <div class="container">
			<aside class="sidebar">
				<h2>What We're Jamming To:</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/0tnnf548YZPUCqhzKZfH4a"></iframe>
			</aside>
			</div>
		  
		
  
    <footer>
	<?php
	include 'includes/footer.php';
	?>
    </footer>
    </div> 

  </body>
</html>