<?php       
    $page_title = 'letlive.';
    $PAGE='letlive';
    require 'includes/header.php';
?>  
          <h1 id ="top">"I've learned to love myself."</h1>

          <main>
			
			<section class="content">
			  <br>
			  <h2><a href="ll">letlive.</a></h2>
			  <br>
			  <img src="http://via.placeholder.com/200x200">
			  <br>
			  <p> On the heavier side of things comes letlive. Very political and high-energy, letlive. might be the perfect band
				to listen to after a break-up or just during a gym workout. One thing is for certain, though: Jason Butler's voice
				cannot be beat in the hardcore scene. (And before you ask, yes, the band name is actually stylized like that.)
			  </p>
			</section>
          </main>
		  
		  
		   <div class="container">
			<aside class="sidebar">
				<h2>What We're Jamming To:</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/0tnnf548YZPUCqhzKZfH4a"></iframe>
			</aside>
			</div>
		  
		
  
    <footer>
	<?php
	include 'includes/footer.php';
	?>
    </footer>
    </div> 

  </body>
</html>