<?php       
    $page_title = 'Dance Gavin Dance';
    $PAGE='DGD';
    require 'includes/header.php';
?> 
	  
          <h1 id ="top">"Ditch your problems, better days are coming."</h1>

          <main>
			
			<section class="content">
			  <br>
			  <h2><a href="dgd">Dance Gavin Dance</a></h2>
			  <br>
			  <img src="http://via.placeholder.com/200x200">
			  <br>
			  <p> Although Dance Gavin Dance has gone through multiple line-up changes, they have still maintained to
				keep lovers of the hardcore scene hooked on them. Between their chaotic album covers, strange lyrics,
				and progressive elements, they never fail to impress (although we would really like to see Jonny back!).
			  </p>
			</section>
          </main>
		  
		  
		   <div class="container">
			<aside class="sidebar">
				<h2>What We're Jamming To:</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/0tnnf548YZPUCqhzKZfH4a"></iframe>
			</aside>
			</div>
		  
		
  
    <footer>
	<?php
	include 'includes/footer.php';
	?>
    </footer>
    </div> 

  </body>
</html>