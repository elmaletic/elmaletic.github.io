<?php
$page_title = 'Shopping Cart';
$PAGE='cart';
require 'includes/header.php';
?>

<h1> Your Shopping Cart:</h1>
<main>

</main>
<div class="container">
			<aside class="sidebar">
				<h2>Relax A Little!</h2>
				<iframe src="https://open.spotify.com/embed/user/1237657570/playlist/7vfjdnQr5I6WjzcxtP5dEt"></iframe>
			</aside>
			</div>

<?php
require 'includes/footer.php';
?>

</body>
</html>